# spotify-downloader 🎵

<b>DISCLAIMER : THIS SCRIPTS ARE FOR EDUCATION PURPOSES ONLY AND ARE NOT INTENDED TO PROMOTE ANY ILLEGAL ACTIVITIES. THE AUTHOR WILL NOT BE HELD RESPONSIBLE FOR ANY MISUSE OF THE INFORMATION PROVIDED<br><br>This Python script lets you download mp3 with a Spotify link or song name from YouTube.<br>
## Deploy to Heroku Fast 👇
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/nimiology/spotify_downloader_telegram__bot/tree/Heroku)





       
<h1>usage👤</h1>
<h3>
Make sure you have FFmpeg on the same folder as the script file if you are on Linux or Mac
</h3>
<p>
Get it from FFmpeg's official site (www.ffmpeg.org)
</p> 
<h3>open terminal and write this command</h3>
<pre>pip install -r requirements.txt</pre>
<h3>open @BotFather(t.me/BotFather) bot in telegram and create your new bot and add your token here in main.py and spotify.py
</h3>
<pre>token = 'token bot'</pre>

<b>now run the Script ;)</b>
